# Thực hành SASS Variables & Mixins

## Mục tiêu
- Sử dụng biến SASS để quản lý màu sắc, kích thước chữ, padding và box-shadow.
- Tạo mixin `button-style` và `box-style` để tái sử dụng CSS.
- Chia SCSS thành các partials theo nhóm chức năng.
- Biên dịch SCSS thành CSS bằng SASS CLI.

## Yêu cầu
Cài Node.js: https://nodejs.org/en/download/

## Cài đặt và biên dịch
```bash
npm install
npm run sass:build
```

## Theo dõi thay đổi tự động
```bash
npm run sass:watch
```
Nhấn `Ctrl+C` để dừng.

## Thử thay đổi giao diện
Sửa các giá trị trong `abstracts/_variables.scss`, lưu lại và chạy lại build hoặc bật watch mode để thấy thay đổi được áp dụng.

## Cấu trúc
- `abstracts/`: biến, mixins và file forward.
- `base/`: kiểu chữ và thiết lập toàn cục.
- `components/`: nút và thẻ nội dung.
- `main.scss`: file đầu vào để biên dịch.
- `css/main.css`: CSS đầu ra được liên kết trong `index.html`.

Dự án dùng `@use` và `@forward` thay cho `@import` cũ.
