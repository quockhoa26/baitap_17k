# Chuyển đổi CSS sang SASS theo chuẩn

## Mục tiêu
- Chuyển CSS truyền thống sang SCSS.
- Tách biến và mixins thành partials.
- Tổ chức mã nguồn theo `abstracts`, `base`, `layout`, `components`.
- Dùng nesting và biên dịch ra CSS.

## Yêu cầu
Cài Node.js: https://nodejs.org/en/download/

## Cài đặt
```bash
npm install
```

## Biên dịch SCSS sang CSS
```bash
npm run sass:build
```

## Theo dõi tự động khi sửa SCSS
```bash
npm run sass:watch
```
Nhấn `Ctrl+C` để dừng watch mode.

## Biên dịch bằng SASS CLI trực tiếp
```bash
npx sass main.scss css/main.css
```

## Cấu trúc
- `abstracts/`: biến, mixins và file forward.
- `base/`: kiểu dáng toàn cục.
- `layout/`: bố cục trang.
- `components/`: nút và thẻ nội dung.
- `main.scss`: điểm vào tập hợp các partials.
- `css/main.css`: CSS đã biên dịch dùng trong trang HTML.

## Lưu ý
Bài sử dụng `@use` và `@forward` thay cho `@import` cũ để phù hợp với SASS hiện đại.
