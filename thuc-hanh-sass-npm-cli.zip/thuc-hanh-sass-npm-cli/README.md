# Thực hành SASS bằng npm và SASS CLI

## Mục tiêu
- Kiểm tra Node.js và npm.
- Cài đặt SASS bằng npm.
- Biên dịch SCSS sang CSS bằng SASS CLI.
- Dùng chế độ `--watch` để tự động biên dịch.
- Biên dịch nhiều file SCSS bằng thư mục đầu vào và đầu ra.

## Yêu cầu
Cài Node.js từ https://nodejs.org/en/download/. npm được cài kèm Node.js.

Kiểm tra phiên bản:

```bash
node -v
npm -v
```

## Cài đặt dự án

Mở terminal tại thư mục dự án và chạy:

```bash
npm install
npx sass --version
```

## Biên dịch một file SCSS

```bash
npx sass scss/styles.scss css/styles.css
```

Sau đó mở `index.html` trong trình duyệt để xem kết quả.

## Theo dõi thay đổi với watch mode

```bash
npm run sass:watch
```

Lệnh này theo dõi thư mục `scss/` và tự động tạo/cập nhật CSS tương ứng trong `css/`. Giữ terminal mở trong khi chỉnh sửa; nhấn `Ctrl+C` để dừng.

## Biên dịch nhiều file SCSS

```bash
npm run sass:all
```

Lệnh trên biên dịch các file SCSS trong `scss/` sang CSS trong `css/`.

## Các script có sẵn

- `npm run sass:build`: biên dịch file `styles.scss`.
- `npm run sass:watch`: tự động biên dịch khi SCSS thay đổi.
- `npm run sass:all`: biên dịch thư mục SCSS sang thư mục CSS.

## Ghi chú
- SASS được cài đặt cục bộ trong dự án dưới dạng dev dependency.
- Dùng `npx sass` để chạy SASS từ dự án.
- `node_modules/` không được đưa lên GitHub; chạy `npm install` để cài lại.
- Các file CSS được giữ trong repository để người chấm có thể xem kết quả biên dịch.
